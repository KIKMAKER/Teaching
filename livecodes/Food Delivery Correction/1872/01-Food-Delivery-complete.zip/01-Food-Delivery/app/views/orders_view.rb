class OrdersView

  def display_list(orders)
    orders.each_with_index do |order, index|
      puts "#{index + 1} #{order.meal.name} for #{order.customer.name} in #{order.customer.address}"
    end
  end

  def ask_for_index(something)
    puts "What is the #{something} number?"
    gets.chomp.to_i - 1
  end

  def display_riders(riders)
    riders.each_with_index do |rider, index|
      puts "#{index + 1}. #{rider.username}"
    end
  end

end
