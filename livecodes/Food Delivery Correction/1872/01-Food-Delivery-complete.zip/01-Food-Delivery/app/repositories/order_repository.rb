require 'csv'
require_relative '../models/order'

class OrderRepository
  def initialize(orders_csv_path, meal_repository, customer_repository, employee_repository)
    @orders_csv_path = orders_csv_path
    @meal_repository = meal_repository
    @customer_repository = customer_repository
    @employee_repository = employee_repository
    @orders = []
    @next_id = 1
    load_csv if File.exist?(@orders_csv_path)
  end

  def undelivered_orders
    # return an array of orders where order.delivered is false
    @orders.reject do |order|
      order.delivered?
    end
  end

  def mark_as_delivered(order)
    order.deliver!
    save_csv
  end

  def my_undelivered_orders(employee)
    @orders.select do |order|
      order.employee == employee && !order.delivered?
    end
  end

  def create(order)
    order.id = @next_id
    @orders << order
    @next_id += 1
    save_csv
  end

  private

  def load_csv
    CSV.foreach(@orders_csv_path, headers: :first_row, header_converters: :symbol) do |row|
      # convert the data types
      row[:id] = row[:id].to_i
      # every other foreign id converted to instance of a class
      meal = @meal_repository.find(row[:meal_id].to_i)
      row[:meal] = meal
      customer = @customer_repository.find(row[:customer_id].to_i)
      row[:customer] = customer
      employee = @employee_repository.find(row[:employee_id].to_i)
      row[:employee] = employee
      row[:delivered] = row[:delivered] == "true"
      @orders << Order.new(row)
    end
    @next_id = @orders.empty? ? 1 : @orders.last.id + 1
  end

  def save_csv
    CSV.open(@orders_csv_path, 'wb') do |csv|
      csv << ['id', 'delivered', 'meal_id', 'customer_id', 'employee_id']
      @orders.each do |order|
        csv << [order.id, order.delivered?, order.meal.id, order.customer.id, order.employee.id]
      end
    end
  end
end
