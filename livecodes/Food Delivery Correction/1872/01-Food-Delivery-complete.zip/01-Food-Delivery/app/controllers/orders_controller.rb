require_relative '../views/orders_view'
require_relative '../views/meals_view'
require_relative '../views/customers_view'
class OrdersController
  def initialize(order_repository, meal_repository, customer_repository, employee_repository)
    @order_repository = order_repository
    @meal_repository = meal_repository
    @customer_repository = customer_repository
    @employee_repository = employee_repository
    @orders_view = OrdersView.new
    @meals_view = MealsView.new
    @customers_view = CustomersView.new
  end

  def list_my_orders(employee)
    # get all the riders orders
    orders = @order_repository.my_undelivered_orders(employee)
    # display them
    @orders_view.display_list(orders)
  end

  def undelivered_orders
    # get all the undelivered orders (REPO)
    undelivered_orders = @order_repository.undelivered_orders
    # display them (VIEW)
    @orders_view.display_list(undelivered_orders)
  end

  def mark_as_delivered(employee)
    # get all the undelivered orders (REPO)
    undelivered_orders = @order_repository.undelivered_orders
    # display them (VIEW)
    @orders_view.display_list(undelivered_orders)
    index = @orders_view.ask_for_index("order")
    order = undelivered_orders[index]
    @order_repository.mark_as_delivered(order)
  end

  def add
    # GET THE MEAL
    meal = get_meal
    # GET THE CUSTOMER
    customer = get_customer
    # GET THE EMPLOYEE
    rider = get_rider
    # Make the order
    new_order = Order.new(meal: meal, customer: customer, employee: rider)
    # save it
    @order_repository.create(new_order)
  end

  private

  def get_meal
    # get all meals
    meals = @meal_repository.all
    # display them
    @meals_view.display_list(meals)
    # ask which meal
    index = @orders_view.ask_for_index("meal")
    # get the meal instance
    meal = meals[index]
    return meal
  end

  def get_customer
    customers = @customer_repository.all
    # display them
    @customers_view.display_list(customers)
    # ask which customer
    index = @orders_view.ask_for_index("customer")
    # get the customer instance
    customer = customers[index]
    return customer
  end

  def get_rider
    riders = @employee_repository.all_riders
    # display them
    @orders_view.display_riders(riders)
    # ask which customer
    index = @orders_view.ask_for_index("rider")
    # get the customer instance
    rider = riders[index]
    return rider
  end
end
