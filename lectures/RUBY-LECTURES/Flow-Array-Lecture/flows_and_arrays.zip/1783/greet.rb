# define your method with a name and parameters
def greet(x, y)
  # code that will be executed when the method is called
  # using the parameters
  puts "Hello dear Mr/Mrs #{y}."
  puts "Thank you for joining us, #{x}."
end
