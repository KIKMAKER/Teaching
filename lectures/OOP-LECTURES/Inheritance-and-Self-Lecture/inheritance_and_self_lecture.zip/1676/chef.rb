class Chef
  attr_reader :name

  def initialize(restaurant, name)
    @restaurant = restaurant
    @name = name
  end
end
