name = "Kiki"

p name
name = String.new("Kiki")


p name.class
